# tmisbackend
# Pre required dependance 
## install php composer
## Run 
   composer install
## To update composer.json
## Run
   composer update

